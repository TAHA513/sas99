
#!/bin/bash
echo "Installing Digital Business Manager..."
npm install
echo "Creating desktop shortcut..."
bash create-shortcut.sh
echo "Installation completed! You can now start the application from your desktop."
  